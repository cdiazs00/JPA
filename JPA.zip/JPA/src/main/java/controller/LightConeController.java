package controller;

import model.Character;
import model.LightCone;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class LightConeController {

    private final Connection connection;
    private EntityManagerFactory entityManagerFactory;

    public LightConeController(Connection connection) {
        this.connection = connection;
    }

    public LightConeController(Connection connection, EntityManagerFactory entityManagerFactory) {
        this.connection = connection;
        this.entityManagerFactory = entityManagerFactory;
    }

    public void newLightCone(LightCone lightCone) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction transaction = entityManager.getTransaction();

        try {
            transaction.begin();
            entityManager.persist(lightCone);
            transaction.commit();
            System.out.println("Cono de luz insertado correctamente en la base de datos.");
        } catch (Exception e) {
            if (transaction != null && transaction.isActive()) {
                transaction.rollback();
            }
            System.err.println("Error al insertar el cono de luz en la base de datos: " + e.getMessage());
        } finally {
            entityManager.close();
        }
    }

    public void updateLightCone(LightCone updatedLightCone) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction transaction = entityManager.getTransaction();

        try {
            transaction.begin();
            entityManager.merge(updatedLightCone);
            transaction.commit();
            System.out.println("Cono de luz actualizado correctamente en la base de datos.");
        } catch (Exception e) {
            if (transaction != null && transaction.isActive()) {
                transaction.rollback();
            }
            System.err.println("Error al actualizar el cono de luz en la base de datos: " + e.getMessage());
        } finally {
            entityManager.close();
        }
    }

    public void deleteLightCone(int id) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction transaction = entityManager.getTransaction();

        try {
            transaction.begin();
            LightCone lightCone = entityManager.find(LightCone.class, id);
            if (lightCone != null) {
                entityManager.remove(lightCone);
                transaction.commit();
                System.out.println("Cono de luz eliminado correctamente de la base de datos.");
            } else {
                System.out.println("No se encontró ningún cono de luz con el ID especificado.");
            }
        } catch (Exception e) {
            if (transaction != null && transaction.isActive()) {
                transaction.rollback();
            }
            System.err.println("Error al eliminar el cono de luz de la base de datos: " + e.getMessage());
        } finally {
            entityManager.close();
        }
    }

    public List<LightCone> readLightConeFile(String filename, String s) throws IOException {
        int id, rareza;
        String nombre;
        List<LightCone> lightconesList = new ArrayList<>();

        BufferedReader br = new BufferedReader(new FileReader(filename));
        String linea;
        while ((linea = br.readLine()) != null) {
            StringTokenizer str = new StringTokenizer(linea, ",");
            id = Integer.parseInt(str.nextToken());
            nombre = str.nextToken();
            rareza = Integer.parseInt(str.nextToken());

            lightconesList.add(new LightCone(id, nombre, rareza));

        }
        br.close();

        return lightconesList;
    }
}
