import java.io.IOException;
import java.sql.Connection;
import java.util.List;
import java.util.Scanner;

import controller.CharacterController;
import controller.LightConeController;
import controller.PathController;
import database.ConnectionFactory;
import model.Character;
import model.LightCone;
import model.Path;
import view.Menu;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * Clase principal que contiene el método main para ejecutar la aplicación.
 */
public class Main {

    /**
     * Método para crear una instancia de EntityManagerFactory.
     * @return La instancia de EntityManagerFactory creada.
     */
    public static EntityManagerFactory createEntityManagerFactory() {
        try {
            return Persistence.createEntityManagerFactory("Honkai");
        } catch (Throwable ex) {
            System.err.println("Failed to create EntityManagerFactory object." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    /**
     * Método principal para ejecutar la aplicación.
     * @param args Los argumentos de la línea de comandos (no utilizados).
     */
    public static void main(String[] args) {
        ConnectionFactory connectionFactory = ConnectionFactory.getInstance();
        Connection c = connectionFactory.connect();

        EntityManagerFactory entityManagerFactory = createEntityManagerFactory();

        CharacterController characterController = new CharacterController(entityManagerFactory);
        LightConeController lightConeController = new LightConeController(c, entityManagerFactory);
        PathController pathController = new PathController(c, entityManagerFactory);

        Menu menu = new Menu();
        int opcio;

        Scanner scanner = new Scanner(System.in);

        do {
            opcio = menu.mainMenu();

            switch (opcio) {
                case 1:
                    try {
                        List<Character> characters = characterController.readCharactersFile("src/main/resources/personajes.txt");
                        List<LightCone> lightCones = lightConeController.readLightConeFile("src/main/resources/conos_de_luz.txt", "src/main/resources/personajes.txt");
                        List<Path> paths = pathController.readPathFile("src/main/resources/vías.txt", "src/main/resources/personajes.txt");

                        System.out.println("Datos de personajes:");
                        for (Character character : characters) {
                            System.out.println(character);
                        }

                        System.out.println("Datos de conos de luz:");
                        for (LightCone lightCone : lightCones) {
                            System.out.println(lightCone);
                        }

                        System.out.println("Datos de vías:");
                        for (Path path : paths) {
                            System.out.println(path);
                        }

                    } catch (NumberFormatException | IOException e) {
                        e.printStackTrace();
                    }
                    break;

                case 2:
                    System.out.println("\nCREAR NUEVO REGISTRO\n");

                    System.out.println("1. Nuevo Personaje");
                    System.out.println("2. Nuevo Cono de Luz");
                    System.out.println("3. Nueva Vía");

                    int option = scanner.nextInt();

                    switch (option) {
                        case 1:
                            System.out.println("Introduce el ID del nuevo personaje:");
                            int id = scanner.nextInt();
                            System.out.println("Introduce el nombre del nuevo personaje:");
                            String name = scanner.next();
                            System.out.println("Introduce la vía del nuevo personaje:");
                            String path = scanner.next();
                            System.out.println("Introduce el elemento del nuevo personaje:");
                            String element = scanner.next();
                            System.out.println("Introduce el id del cono de luz del nuevo personaje:");
                            int lightCone = scanner.nextInt();

                            Character newCharacter = new Character(id, name, path, element, lightCone);
                            characterController.newCharacter(newCharacter);
                            break;

                        case 2:
                            System.out.println("Introduce el ID del nuevo cono de luz:");
                            id = scanner.nextInt();
                            System.out.println("Introduce el nombre del nuevo cono de luz:");
                            name = scanner.next();
                            System.out.println("Introduce la rareza del nuevo cono de luz:");
                            int rarity = scanner.nextInt();

                            LightCone newLightCone = new LightCone(id, name, rarity);
                            lightConeController.newLightCone(newLightCone);
                            break;

                        case 3:
                            System.out.println("Introduce el ID de la nueva vía:");
                            id = scanner.nextInt();
                            System.out.println("Introduce el nombre de la nueva vía:");
                            name = scanner.next();
                            System.out.println("Introduce el eón de la nueva vía:");
                            String eon = scanner.next();

                            Path newPath = new Path(id, name, eon);
                            pathController.newPath(newPath);
                            break;
                    }
                    break;

                case 3:
                    System.out.println("\nEDITAR REGISTRO EXISTENTE\n");

                    System.out.println("1. Editar Personaje");
                    System.out.println("2. Editar Cono de Luz");
                    System.out.println("3. Editar Vía");

                    int editOption = scanner.nextInt();

                    switch (editOption) {
                        case 1:
                            System.out.println("Introduce el ID del personaje a editar:");
                            int id = scanner.nextInt();
                            System.out.println("Introduce el nombre del personaje:");
                            String name = scanner.next();
                            System.out.println("Introduce la vía del personaje:");
                            String path = scanner.next();
                            System.out.println("Introduce el elemento del personaje:");
                            String element = scanner.next();
                            System.out.println("Introduce el id del cono de luz del personaje:");
                            int lightCone = scanner.nextInt();

                            Character updatedCharacter = new Character(id, name, path, element, lightCone);
                            characterController.updateCharacter(updatedCharacter);
                            break;

                        case 2:
                            System.out.println("Introduce el ID del cono de luz a editar:");
                            id = scanner.nextInt();
                            System.out.println("Introduce el nombre del cono de luz:");
                            name = scanner.next();
                            System.out.println("Introduce la rareza del cono de luz:");
                            int rarity = scanner.nextInt();

                            LightCone updatedLightCone = new LightCone(id, name, rarity);
                            lightConeController.updateLightCone(updatedLightCone);
                            break;

                        case 3:
                            System.out.println("Introduce el ID de la vía a editar:");
                            id = scanner.nextInt();
                            System.out.println("Introduce el nombre de la vía:");
                            name = scanner.next();
                            System.out.println("Introduce el eón de la vía:");
                            String eon = scanner.next();

                            Path updatedPath = new Path(id, name, eon);
                            pathController.updatePath(updatedPath);
                            break;
                    }
                    break;

                case 4:
                    System.out.println("\nBORRAR REGISTRO EXISTENTE\n");

                    System.out.println("1. Borrar Personaje");
                    System.out.println("2. Borrar Cono de Luz");
                    System.out.println("3. Borrar Vía");

                    int deleteOption = scanner.nextInt();

                    switch (deleteOption) {
                        case 1:
                            System.out.println("Introduce el ID del personaje a borrar:");
                            int id = scanner.nextInt();
                            characterController.deleteCharacter(id);
                            break;

                        case 2:
                            System.out.println("Introduce el ID del cono de luz a borrar:");
                            id = scanner.nextInt();
                            lightConeController.deleteLightCone(id);
                            break;

                        case 3:
                            System.out.println("Introduce el ID de la vía a borrar:");
                            id = scanner.nextInt();
                            pathController.deletePath(id);
                            break;
                    }
                    break;

                default:
                    System.out.println("¡Adios!");
                    System.exit(0);
            }
        } while (true);
    }
}