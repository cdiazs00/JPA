CREATE TABLE personajes
(
    id_personaje integer NOT NULL,
    nombre character varying(50) NOT NULL,
    vía character varying(50) NOT NULL,
    elemento character varying(50) NOT NULL,
    id_cono_de_luz integer NOT NULL,
    CONSTRAINT pk_personajes PRIMARY KEY (id_personaje),
    CONSTRAINT fk_personajes FOREIGN KEY (id_cono_de_luz)
          REFERENCES conos_de_luz (id_cono_de_luz) MATCH SIMPLE
          ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE vías
(
    id_vía serial NOT NULL,
    vía character varying(50) NOT NULL,
    eón character varying(50) NOT NULL,
    CONSTRAINT pk_vías PRIMARY KEY (id_vía),
    CONSTRAINT uk_vía UNIQUE (vía)
);

CREATE TABLE conos_de_luz
(
    id_cono_de_luz serial NOT NULL,
    nombre character varying(50) NOT NULL,
    rareza integer NOT NULL,
    CONSTRAINT pk_conos_de_luz PRIMARY KEY (id_cono_de_luz),
    CONSTRAINT uk_conos_de_luz UNIQUE (nombre)
);